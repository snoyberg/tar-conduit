Haskell libpq binding
---------------------

This is a Haskell binding to libpq: the C application programmer's
interface to PostgreSQL. libpq is a set of library functions that
allow client programs to pass queries to the PostgreSQL backend server
and to receive the results of these queries.